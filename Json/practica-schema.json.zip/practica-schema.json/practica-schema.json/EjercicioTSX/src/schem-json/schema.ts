// schema-detallado.ts
export const esquemaDetallado = {
  $schema: "http://json-schema.org/draft-07/schema#",
  title: "Esquema de Jugador NBA",
  description: "Estructura de datos para jugadores de la NBA",
  type: "object",
  properties: {
      firstName: { 
          type: "string",
          minLength: 2,
          maxLength: 30,
          pattern: "^[A-Z][a-zA-Z'-]*$"  // Empieza con mayúscula
      },
      lastName: { 
          type: "string",
          minLength: 2,
          maxLength: 30,
          pattern: "^[A-Z][a-zA-Z'-]*$"
      },
      playerId: { 
          type: "integer", 
          minimum: 100000,
          maximum: 9999999
      },
      teamId: { 
          type: "integer",
          enum: [
              // Todos los teamIds de la NBA...
              0, 1610612737, 1610612738, /* ...otros IDs */
          ]
      },
      position: {  // Campo opcional si lo agregas después
          type: "string",
          enum: ["PG", "SG", "SF", "PF", "C", "G", "F"],
          default: null
      }
  },
  required: ["firstName", "lastName", "playerId", "teamId"],
  additionalProperties: false
};