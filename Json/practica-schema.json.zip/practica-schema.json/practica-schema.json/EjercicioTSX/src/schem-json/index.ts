import fs from 'fs';
import path from 'path';
import Ajv from 'ajv';

// JSON Schema para validar los datos de jugadores NBA
const esquema = {
  type: "object",
  properties: {
    firstName: { type: "string" },
    lastName: { type: "string" },
    playerId: { type: "integer" },
    teamId: { type: "integer" }
  },
  required: ["firstName", "lastName", "playerId", "teamId"],
  additionalProperties: false
};

// Crear una instancia de Ajv para validar los datos
const ajv = new Ajv();
const validar = ajv.compile(esquema);

// Función filter: Filtrar jugadores por teamId
function filtrarPorEquipo(datos: any[], equipoId: number) {
  return datos.filter((jugador) => jugador.teamId === equipoId);
}

// Función map: Extraer nombres completos de los jugadores
function extraerNombresCompletos(datos: any[]) {
  return datos.map((jugador) => `${jugador.firstName} ${jugador.lastName}`);
}

// Función reduce: Contar cuántos jugadores hay por equipo
function contarPorEquipo(datos: any[]) {
  return datos.reduce((acumulador, jugador) => {
    acumulador[jugador.teamId] = (acumulador[jugador.teamId] || 0) + 1;
    return acumulador;
  }, {});
}

// Función adicional: Buscar jugador por ID
function buscarPorId(datos: any[], id: number) {
  return datos.find((jugador) => jugador.playerId === id);
}

// Leer y procesar el archivo JSON
const rutaArchivo = path.join(__dirname, 'datos', 'jugadores.json');

fs.readFile(rutaArchivo, 'utf-8', (err, data) => {
  if (err) {
    console.error('Error al leer el archivo:', err);
    return;
  }

  // Convertir el JSON a un objeto
  const datos = JSON.parse(data);

  // Filtrar los datos válidos
  const datosValidos = datos.filter((jugador: any) => {
    const esValido = validar(jugador);
    if (!esValido) {
      console.error('Dato de jugador no válido:', jugador, validar.errors);
    }
    return esValido;
  });

  // Usar las funciones adicionales
  const jugadoresLakers = filtrarPorEquipo(datosValidos, 1610612747); // Filtrar jugadores de Lakers
  const nombresCompletos = extraerNombresCompletos(datosValidos);
  const conteoPorEquipo = contarPorEquipo(datosValidos);
  const jugadorEspecifico = buscarPorId(datosValidos, 203507); // Buscar a Giannis Antetokounmpo

  // Mostrar resultados
  console.log('Jugadores de Los Angeles Lakers:', jugadoresLakers);
  console.log('Nombres completos de todos los jugadores:', nombresCompletos);
  console.log('Conteo de jugadores por equipo:', conteoPorEquipo);
  console.log('Jugador con ID 203507 (Giannis):', jugadorEspecifico);

  // Guardar resultados en archivos
  fs.writeFileSync('jugadores_lakers.json', JSON.stringify(jugadoresLakers, null, 2));
  fs.writeFileSync('conteo_equipos.json', JSON.stringify(conteoPorEquipo, null, 2));
});