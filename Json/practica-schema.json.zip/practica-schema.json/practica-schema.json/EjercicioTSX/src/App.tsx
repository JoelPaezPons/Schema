import React, { useState } from "react";
import "./index.css";
import jugadoresJSON from "./schem-json/datos/jugadores.json";

// Definir tipo de datos para jugadores
interface Jugador {
  firstName: string;
  lastName: string;
  playerId: number;
  teamId: number;
}

// Mapeo de los teamId a los nombres de equipos
const equiposNBA: { [key: number]: string } = {
  1610612737: "Hawks",
  1610612738: "Celtics",
  1610612739: "Cavaliers",
  1610612740: "Pelicans",
  1610612741: "Bulls",
  1610612742: "Mavericks",
  1610612743: "Nuggets",
  1610612744: "Warriors",
  1610612745: "Rockets",
  1610612746: "Clippers",
  1610612747: "Lakers",
  1610612748: "Heat",
  1610612749: "Bucks",
  1610612750: "Timberwolves",
  1610612751: "Nets",
  1610612752: "Knicks",
  1610612753: "Magic",
  1610612754: "Pacers",
  1610612755: "76ers",
  1610612756: "Suns",
  1610612757: "Trail Blazers",
  1610612758: "Kings",
  1610612759: "Spurs",
  1610612760: "Thunder",
  1610612761: "Raptors",
  1610612762: "Jazz",
  1610612763: "Grizzlies",
  1610612764: "Wizards",
  1610612765: "Pistons",
  1610612766: "Hornets",
  0: "Free Agent",
};

const App: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Filtrar los jugadores por su nombre apellido o su ID
  const filteredPlayers = jugadoresJSON.filter((jugador: Jugador) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      jugador.firstName.toLowerCase().includes(searchLower) ||
      jugador.lastName.toLowerCase().includes(searchLower) ||
      jugador.playerId.toString().includes(searchTerm)
    );
  });

  // Aqui se mostrara el titulo, la barra para buscar por nombre, apellido o ID
  return (
    <div className="container">
      <h1>🏀 Lista de Jugadores NBA 🏀</h1>
      
      <input
        type="text"
        className="search-box"
        placeholder="🔍 Buscar por nombre, apellido o ID..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <ul className="player-list">
        {filteredPlayers.map((jugador: Jugador, index: number) => (
          <li key={index} className="player-item">
            <span>👤 {jugador.firstName} {jugador.lastName}</span>
            <span>🆔 ID: {jugador.playerId}</span>
            <span>🏀 Equipo: {equiposNBA[jugador.teamId] || "Desconocido"}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;